# Rohit Laundry Website — Design Direction

## Three possible stylistic approaches

### 1. Pressed Blue Atelier
**Very Brief Intro:** A precise, confident service identity inspired by the crisp fold lines of freshly pressed garments. It uses editorial spacing, navy ink, soft blue paper, and tactile, utility-led visual details.

**Probability:** 0.04

### 2. Monsoon Freshness
**Very Brief Intro:** A bright, airy direction that balances monsoon-blue hues with sun-washed cream, delicate water ripples, and a friendly neighborhood spirit.

**Probability:** 0.07

### 3. Surat Workshop Ledger
**Very Brief Intro:** A warm industrial approach for a laundry that serves both families and garment businesses, using workshop labels, practical tables, and textured fabric swatches.

**Probability:** 0.02

---

## Chosen approach: Pressed Blue Atelier

### Design Movement
This site adopts an **editorial utility design** approach: a contemporary service identity informed by printmaking, garment care labels, and precise tailoring measurements. It should feel local and attentive rather than corporate or overly polished.

### Core Principles
1. **Crisp clarity:** Information is structured like a well-organized garment-care label, with strong hierarchy and straightforward conversion paths.
2. **Tactile confidence:** Fine rules, stitched-line motifs, fold marks, and light paper texture make the digital experience feel crafted.
3. **Mobile convenience first:** Calls and WhatsApp actions are large, obvious, and always close at hand without obscuring content.
4. **Honest local service:** Copy speaks with direct, helpful confidence and avoids unsupported superlatives, ratings, or invented testimonials.

### Color Philosophy
The canvas is warm off-white rather than sterile white, projecting care and approachability. A deep **pressing-ink navy** anchors trust, a washed blue carries freshness and water associations, and a restrained mint-green is reserved solely for WhatsApp and service-confirmation emphasis. Terracotta is used sparingly to direct the eye toward the bulk-order business lane.

### Layout Paradigm
The page moves in **editorial bands** rather than a conventional centered-card grid. Hero copy sits on an asymmetric two-part service-ticket composition; service information is organized as a numbered catalogue with a strong vertical spine; locality coverage becomes a folded-paper map of service zones; and mobile keeps all key actions in an ergonomic action dock.

### Signature Elements
1. A **fold-line** graphic system: thin offset rules, crop-mark corners, and fold shadows.
2. A bold **laundry stamp** containing a simple water-drop-and-fold symbol.
3. A **service ticket** motif for calls to action, enquiry information, and bulk-service highlights.

### Interaction Philosophy
Interactions should feel practical and responsive. Buttons compress slightly when tapped, details accordions open decisively, and the navigation converts to a full-width utility panel on small screens. Every interactive item presents a visible keyboard focus state.

### Animation
Use only short, functional motion: 150–220ms transforms and fades with a crisp custom ease-out. The hero stamp has a subtle one-time settling motion; section elements can appear in a restrained stagger when entering the viewport. No auto-play video, looping decorative motion, or animation that changes layout. All nonessential movement is disabled when reduced motion is preferred.

### Typography System
Use **DM Serif Display** for distinctive, high-trust headlines and **Manrope** for dense, highly legible service details and controls. Headlines have tight, confident line-height; body text remains open and practical; metadata is uppercase in Manrope with generous letter spacing. No Inter.

### Brand Essence
**Rohit Laundry is the clear, dependable Surat garment-care partner for everyday laundry and exacting bulk steam press needs.**

**Personality:** meticulous, welcoming, capable.

### Brand Voice
Headlines are direct and specific; CTAs use service language rather than generic marketing language; microcopy reassures users that availability can be checked quickly.

Example lines: “Fresh folds. Sharp finish. One quick call away.” and “Need pickup in your area? Send your location on WhatsApp.”

### Wordmark & Logo
The wordmark pairs a bold “ROHIT” with a small, spaced “LAUNDRY” line, framed by a circular **water-drop fold mark**. The standalone mark uses a navy droplet enclosing one clean folded-garment line, so it remains recognizable in a favicon and mobile header without relying on text.

### Signature Brand Color
**Pressing Ink — #113A5D**

## Style Decisions

- The **fold-line system** is a primary brand motif: every major content band receives a visible crop-mark, folded-paper, stitched-rule, service-ticket or stamp detail rather than relying only on colour and typography.
- The **Rohit Laundry mark and wordmark** appear as a confident recurring service seal in the hero, service-ticket calls to action, bulk-order lane and footer.
- In the absence of verified reviews, the review area uses **clearly labelled verification slips** instead of simulated testimonials, ratings or customer identities.
- Imagery is framed as physical garment-care evidence, with paper labels, tailored crops, visible textile texture and pressing-workshop cues rather than generic lifestyle treatment.
- The service-areas display uses a **folded service-route ledger** treatment so locality information feels distinctive without implying a physical shop in each location.
